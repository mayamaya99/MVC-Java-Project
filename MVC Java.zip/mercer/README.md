# project-skeleton
A starter MVC project for CSD297 projects

_(Note: This is an example of an MVC-based website created using the Java Servlet API. It is part of the curriculum for CSD 297 at Lake Washington Institute of Technology.)_

### "Elevator Pitch"
This skeleton project...

### Project Documentation
[Wiki](../../wiki)
